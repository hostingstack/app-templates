<?php
    echo "<h1>Hello world!</h1>";
?>
