UPDATE `@@DB_MAIN_PREFIX@@adminnotification_inbox` SET is_read = 1 where notification_id < 34;
UPDATE `@@DB_MAIN_PREFIX@@core_config_data` SET `value` = '0' WHERE `path` = 'web/seo/use_rewrites';
REPLACE INTO `@@DB_MAIN_PREFIX@@core_config_data` (scope, path, value) VALUES ('default', 'web/unsecure/base_url', '@@ROOT_URL@@/');

