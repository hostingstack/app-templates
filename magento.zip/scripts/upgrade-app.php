<?php
require_once('app-util.php');
require_once('file-util.php');

function upgrade_app($from_ver, $from_rel, $config_files, $db_ids, $psa_modify_hash, $db_modify_hash, $settings_modify_hash, $crypt_settings_modify_hash, $settings_enum_modify_hash, $additional_modify_hash, $writable_configs){
//    $upgrade_schema_files = get_upgrade_schema_files($argv[2], $argv[3]);
//    $upgrade_schema_files = array(); // array('upgrade-1.0-1.sql' => 'main')
	$upgrade_schema_files = array( 'upgrade.sql' => 'main' );

	delete_directory($psa_modify_hash['@@ROOT_DIR@@'].'/var/cache/');
	delete_directory($psa_modify_hash['@@ROOT_DIR@@'].'/var/session/');
	delete_directory($psa_modify_hash['@@ROOT_DIR@@'].'/includes/src/', 1);

	mysql_db_connect(get_db_address('main'), get_db_login('main'),
		get_db_password('main'), get_db_name('main'));

	$cache_settings = get_cache_settings();
	disable_cache();
	do_upgrade($psa_modify_hash["@@ROOT_URL@@"]."/");
	restore_cache_settings($cache_settings);

    configure($config_files, $upgrade_schema_files, $db_ids, $psa_modify_hash, $db_modify_hash, $settings_modify_hash, $crypt_settings_modify_hash, $settings_enum_modify_hash, $additional_modify_hash, $writable_configs);

    return 0;
}

function delete_directory($dir, $keep_root_dir = 0)
{
	if (!file_exists($dir)) {
		return;
	}
	if ($handle = opendir($dir)) {
		while ($file = readdir($handle)) {
			if ($file != '.' && $file != '..') {
				if(is_dir($dir.$file)) {
					$dir_contents = scandir($dir.$file);
					if(count($dir_contents) > 2 || !rmdir($dir.$file)) {
						delete_directory($dir.$file.'/');
					}
				} else {
					unlink($dir.$file);
				}
			}
		}
	}
	closedir($handle);
	if ( $keep_root_dir == 0 ) {
		rmdir($dir);
	}
}

function do_upgrade($magento_url) 
{
	// to upgrade magento, we need only point browser to any Magento page
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$magento_url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); // return into a variable
	curl_setopt($ch, CURLOPT_TIMEOUT, 1200); 
	$result = curl_exec($ch); // run the whole process
}

function get_cache_settings()
{
	$cache_settings = array();

	$result = mysql_query('SELECT `code`, `value` from `'.get_db_prefix('main').'core_cache_option`');

	if (!$result) {
		return $cache_settings;
	}
	while ($row = mysql_fetch_assoc($result)) {
		$cache_settings[$row['code']] = $row['value'];
	}
	return $cache_settings;
}

function disable_cache()
{
	mysql_query('UPDATE `'.get_db_prefix('main').'core_cache_option` SET `value`=0');
}

function restore_cache_settings($cache_settings)
{
	foreach ($cache_settings as $code => $value) {
		mysql_query("UPDATE `".get_db_prefix('main')."core_cache_option` SET `value`='".$value."' WHERE `code` = '".$code."'");
	}
}

?>
