<?php
require_once('app-util.php');
require_once('file-util.php');

function upgrade_app($from_ver, $from_rel, $config_files, $db_ids, $psa_modify_hash, $db_modify_hash, $settings_modify_hash, $crypt_settings_modify_hash, $settings_enum_modify_hash, $additional_modify_hash){
	//    $upgrade_schema_files = get_upgrade_schema_files($argv[2], $argv[3]);

	if (preg_match("/^1\.5[$\.]/", $from_ver)) {
		$upgrade_schema_files = array( 'rename_j15.sql' => 'main', # rename joomla 15 default tables
										'schema.sql' => 'main', 'enable-auto-login.sql' => 'main', # joomla 1.6.1 install
										'com_jupgrade_install.sql' => 'main'  ); # jupgrade plugin schema
		$config_files = array(  '/' => array( array( 'configuration.php.in', 'configuration.php' ), 
										array( 'jupgrade_defines.php.in', 'joomla15/administrator/components/com_jupgrade/admin/includes/defines.php' ), 
										array( 'configuration15.php.in', 'joomla15/configuration.php' ) ),
								'/cgi-bin' => array() );
		$psa_modify_hash['@@ROOT_DIR_j15@@'] = $psa_modify_hash['@@ROOT_DIR@@']."/joomla15";
		enable_jupgrade();
	} else if (preg_match("/^1\/6[$\.]/", $from_ver)) {
		$upgrade_schema_files = array('upgrade-1.6.x-1.7.0.sql' => 'main', 'enable-auto-login.sql' => 'main');
	} else if (preg_match("/^1\/7\.0$/", $from_ver)) {
		$upgrade_schema_files = array('joomla_update_170to171.sql' => 'main', 'joomla_update_172to173.sql' => 'main', 'enable-auto-login.sql' => 'main');
	} else {
		$upgrade_schema_files = array('enable-auto-login.sql' => 'main');
	}

	configure($config_files, $upgrade_schema_files, $db_ids, $psa_modify_hash, $db_modify_hash, $settings_modify_hash, $crypt_settings_modify_hash, $settings_enum_modify_hash, $additional_modify_hash);

	if (preg_match("/1\.5[$\.]/", $from_ver)) {
		try {
			// call native import script
			define("APS_UPGRADE", "Yes");
			include($psa_modify_hash['@@ROOT_DIR@@']."/joomla15/administrator/components/com_jupgrade/admin/includes/controller.php");
			#include($psa_modify_hash['@@ROOT_DIR@@']."/joomla15/administrator/components/com_jupgrade/admin/includes/templates_db.php");
			#include($psa_modify_hash['@@ROOT_DIR@@']."/joomla15/administrator/components/com_jupgrade/admin/includes/templates_files.php");
			#include($psa_modify_hash['@@ROOT_DIR@@']."/joomla15/administrator/components/com_jupgrade/admin/includes/extensions.php");
		} catch (Exception $e) {
			echo "\n\nImport Error: ".$e->getMessage()."\n\n";
			exit(1);
		}
	}

	if ( file_exists($psa_modify_hash['@@ROOT_DIR@@']."/installation") ) {
		delete_directory($psa_modify_hash['@@ROOT_DIR@@']."/installation");
	}

	if ( file_exists($psa_modify_hash['@@ROOT_DIR@@']."/joomla15")  ) {
		delete_directory($psa_modify_hash['@@ROOT_DIR@@']."/joomla15");
	}

	//Bad to enable tinymce_localization here because it breaks tinymce for manually installed localizations
	//enable_tinymce_localization();

	return 0;
}


function enable_tinymce_localization(){
	$db_id = "main";
    mysql_db_connect(get_db_address($db_id),
          get_db_login($db_id),
          get_db_password($db_id),
          get_db_name($db_id));

    $result = mysql_query("SELECT `params` FROM `".get_db_prefix($db_id)."jos_plugins` WHERE `name`='Editor - TinyMCE 2.0'");
    if ($result) {
        $tinyparams = mysql_result($result, 0);
		$tinyparams2 = preg_replace("/lang_mode=0/","lang_mode=1", $tinyparams);
		$query = sprintf("UPDATE `".get_db_prefix($db_id)."jos_plugins` SET `params`='%s'",
            mysql_real_escape_string($tinyparams2));
		mysql_query($query);
    }
}

function enable_jupgrade() {
	$db_id = "main";
	mysql_db_connect(get_db_address($db_id),
		get_db_login($db_id),
		get_db_password($db_id),
		get_db_name($db_id));

	$result = mysql_query("SELECT id FROM `".get_db_prefix($db_id)."jos_components` WHERE `option`='com_jupgrade'");
	if ($result && $row = mysql_fetch_row($result)) {
		mysql_query("UPDATE `".get_db_prefix($db_id)."jos_components` SET enabled=1 WHERE `option`='com_jupgrade'");
	} else {
		mysql_query("INSERT INTO `".get_db_prefix($db_id)."jos_components` (name, link, menuid, parent, admin_menu_link, admin_menu_alt, `option`, ordering,admin_menu_img,iscore,params,enabled) VALUES ('jUpgrade','option=com_jupgrade',0,0,'option=com_jupgrade','jUpgrade','com_jupgrade',0,'components/com_jupgrade/images/jupgrade.png',0,'positions=0',1)");
	}

	$result = mysql_query("SELECT id FROM `".get_db_prefix($db_id)."jos_plugins` WHERE `element`='mtupgrade'");
	if ($result && $row = mysql_fetch_row($result)) {
		 mysql_query("UPDATE `".get_db_prefix($db_id)."jos_plugins` SET published=1 WHERE `element`='mtupgrade'");
	} else {
		mysql_query("INSERT INTO `".get_db_prefix($db_id)."jos_plugins` (`name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES ('System - Mootools Upgrade','mtupgrade','system',0,8,1,1,0,0,'0000-00-00 00:00:00','')");
	}
}

function get_joomla_version() {
	$db_id = "main";
	mysql_db_connect(get_db_address($db_id),
		get_db_login($db_id),
		get_db_password($db_id),
		get_db_name($db_id));

	$task_id = 0;
	$result = mysql_query("SHOW TABLES LIKE  `".get_db_prefix($db_id)."jos_extensions`");
	if ($result && $row = mysql_fetch_row($result)) {
		return "1.6.1";
	}
	return "1.5.20";
}

?>
