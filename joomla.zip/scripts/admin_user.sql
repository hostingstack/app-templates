#INSERT INTO `@@DB_MAIN_PREFIX@@jos_core_acl_aro` VALUES (10,'users','62',0,'Administrator',0);
UPDATE `@@DB_MAIN_PREFIX@@jos_extensions` SET `params`='{"administrator":"@@LOCALE@@","site":"@@LOCALE@@"}' WHERE `name`='com_languages';
INSERT INTO `@@DB_MAIN_PREFIX@@jos_user_usergroup_map` VALUES (62,8);
INSERT INTO `@@DB_MAIN_PREFIX@@jos_users` VALUES (62,'Administrator','@@ADMIN_NAME@@','@@ADMIN_EMAIL@@','@@ADMIN_PASSWORD@@','Super Administrator',0,1,NOW(),'0000-00-00 00:00:00','','');



