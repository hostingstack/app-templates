INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_plugins` VALUES (34, 'System - Mootools Upgrade', 'mtupgrade', 'system', 0, 8, 0, 1, 0, 0, '0000-00-00 00:00:00', '');

