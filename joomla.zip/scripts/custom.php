<?php
require_once('env-parser.php');
require_once('file-util.php');

function admin_password_crypt($value)
{
    return md5($value);
}

function get_localized_schema_files()
{
	$schema_files = array( 'schema.sql' => 'main', 'admin_user.sql' => 'main', 'enable-auto-login.sql' => 'main' );
	$locale = fetch_env_var('SETTINGS_locale');
	$default_lang = fetch_env_var('SETTINGS_default_lang');
	if ($default_lang != '') // override locale during installation
	{
		$locale = $default_lang;
	}
	$fname = "${locale}_data.sql";
	if ($locale == '' or !@file_exists($fname))
	{
		$fname = 'en-GB_data.sql';
	}
	$schema_files[$fname] = 'main';

	return $schema_files;
}

function rebuild_config_file($old_config_file, $file_source, $file_dest, $meta_settings) {
    $file_content = read_file($file_source);
	
	require_once "$old_config_file";
	$old_conf = new JConfig();

	foreach (get_object_vars($old_conf) as $key => $value) {
		foreach ($meta_settings as $field) {
			if ($key == $field) {
				continue 2;
			}
		}
		$file_content = preg_replace('/public \$'.$key.' = .*?;\n/', 'public \$'.$key." = '".php_quote($value)."';\n", $file_content);
	}
    write_file($file_dest, $file_content);
}

function get_additional_modify_hash()
{
    $parameters = array();
    $parameters['@@SECRET_KEY@@'] = genRandomPassword(16);
    return $parameters;
}

/**
 * Generate a random password
 *
 * @param       int             $length Length of the password to generate
 * @return      string                  Random Password
 */
function genRandomPassword($length = 8)
{
        $salt = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $len = strlen($salt);
        $makepass = '';
        mt_srand(10000000 * (double) microtime());

        for ($i = 0; $i < $length; $i ++) {
                $makepass .= $salt[mt_rand(0, $len -1)];
        }

        return $makepass;
}



?>
