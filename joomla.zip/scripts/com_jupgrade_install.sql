--
-- Table structure for table `@@DB_MAIN_PREFIX@@jos_jupgrade_categories`
--

CREATE TABLE IF NOT EXISTS `@@DB_MAIN_PREFIX@@jos_jupgrade_categories` (
  `old` int(11) NOT NULL,
  `new` int(11) NOT NULL,
  `section` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `@@DB_MAIN_PREFIX@@jos_jupgrade_menus`
--

CREATE TABLE IF NOT EXISTS `@@DB_MAIN_PREFIX@@jos_jupgrade_menus` (
  `old` int(11) NOT NULL,
  `new` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `@@DB_MAIN_PREFIX@@jos_jupgrade_steps`
--

CREATE TABLE IF NOT EXISTS `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `status` int(11) NOT NULL,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `@@DB_MAIN_PREFIX@@jos_jupgrade_steps`
--

INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(1, 'users', 0);
INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(2, 'modules', 0);
INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(3, 'categories', 0);
INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(4, 'content', 0);
INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(5, 'menus', 0);
INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(6, 'banners', 0);
INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(7, 'contacts', 0);
INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(8, 'newsfeeds', 0);
INSERT IGNORE INTO `@@DB_MAIN_PREFIX@@jos_jupgrade_steps` VALUES(9, 'weblinks', 0);

--
-- Table structure for table `@@DB_MAIN_PREFIX@@jos_jupgrade_modules`
--

CREATE TABLE IF NOT EXISTS `@@DB_MAIN_PREFIX@@jos_jupgrade_modules` (
  `old` int(11) NOT NULL,
  `new` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
