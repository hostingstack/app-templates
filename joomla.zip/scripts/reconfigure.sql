SET NAMES UTF8;
UPDATE `@@DB_MAIN_PREFIX@@jos_users` SET `username`='@@ADMIN_NAME@@', `email`='@@ADMIN_EMAIL@@', `password`='@@ADMIN_PASSWORD@@' WHERE `id`=62;
