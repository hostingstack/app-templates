INSERT INTO `@@DB_MAIN_PREFIX@@jos15_components` (name, link, menuid, parent, admin_menu_link, admin_menu_alt, `option`, ordering,admin_menu_img,iscore,params,enabled) VALUES ('jUpgrade','option=com_jupgrade',0,0,'option=com_jupgrade','jUpgrade','com_jupgrade',0,'components/com_jupgrade/images/jupgrade.png',0,'positions=0',1);

